export class TreatmentDTO {
  nameIllness: string = '';
  quantityTreatments: number = 0;
}
