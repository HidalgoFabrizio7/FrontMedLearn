export class Totaldecaloriesbydiet{
  idDiet: number=0
  description: string=""
  totalCaloriesPorDieta: number=0
}
