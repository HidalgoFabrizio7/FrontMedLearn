export class Illness{
    idIllness: number=0
    nameIllness: string=""
    descriptionIllness: string=""
    imageIllness:string=""
    searchesIllneses: number=0
}