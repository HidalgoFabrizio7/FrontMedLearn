export class TotaldeexercisesbyDietas{
  idDiet: number=0
  description: string=""
  totalExercisesporDieta: number=0
}
