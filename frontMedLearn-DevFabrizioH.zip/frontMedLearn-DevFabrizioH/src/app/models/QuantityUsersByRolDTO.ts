export class QuantityUsersByRolDTO{
  rol: string=""
  usuarios: number=0
}
