import { Diet } from "./Diet"

export class Exercise
{
  idExercise: number=0
  nameExercise: string=""
  setsExercise:number=0
  diet:Diet=new Diet()
}
