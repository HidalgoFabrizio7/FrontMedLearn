export class Users{
  idUser: number=0
  fullnameUser: string=""
  username: string=""
  password: string=""
  enabled: boolean=true
  email:string=""
  certificationUser: string=""
}
