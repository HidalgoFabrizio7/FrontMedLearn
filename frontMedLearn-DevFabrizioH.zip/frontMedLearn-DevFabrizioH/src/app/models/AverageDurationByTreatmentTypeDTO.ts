export class AverageDurationByTreatmentTypeDTO{
  treatmentDescription:string=""
  averageDuration:number=0
}
