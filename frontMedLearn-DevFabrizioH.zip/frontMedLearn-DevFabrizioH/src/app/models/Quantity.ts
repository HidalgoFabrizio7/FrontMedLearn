import { Exercise } from "./Exercise"
import { Food } from "./Food"
import { Medicine } from "./Medicine"

export class Quantity{
  idQuantity: number=0
  quantityQuantity : number=0
  medicine:Medicine=new Medicine()
  food:Food=new Food()
  exercise:Exercise =new Exercise()


}
        