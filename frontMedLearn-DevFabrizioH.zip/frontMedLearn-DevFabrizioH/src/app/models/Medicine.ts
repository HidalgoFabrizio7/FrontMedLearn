import { Treatments } from "./treatments"

export class Medicine{
    idMedicine: number=0
    descriptionMedicine: string=""
    nameMedicine: string=""
    treatment:Treatments = new Treatments()
}

