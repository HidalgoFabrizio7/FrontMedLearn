export class QuantityBydietsinicidasydietsfinalizadasbyuser{
    username:string=""
    cantidadDeDietasIniciadas:number=0
    cantidadDietasFinalizadas:number=0
}