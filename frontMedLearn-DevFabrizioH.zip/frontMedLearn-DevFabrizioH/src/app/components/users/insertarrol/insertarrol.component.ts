import { Component } from '@angular/core';

@Component({
  selector: 'app-insertarrol',
  standalone: true,
  imports: [],
  templateUrl: './insertarrol.component.html',
  styleUrl: './insertarrol.component.css'
})
export class InsertarrolComponent {

}
