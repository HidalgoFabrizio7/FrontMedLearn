import { Component } from '@angular/core';

@Component({
  selector: 'app-historialdietas',
  standalone: true,
  imports: [],
  templateUrl: './historialdietas.component.html',
  styleUrl: './historialdietas.component.css'
})
export class HistorialdietasComponent {
  
}
