import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-EWPFDFUF.js";
import "./chunk-LA2LXNQC.js";
import "./chunk-MKMF3MR4.js";
import "./chunk-6QMRW5JT.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-VLMTOHV6.js";
import "./chunk-TYE4XF4J.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-UADNY2ZJ.js";
import "./chunk-2UAWGDSU.js";
import "./chunk-F4IYSBV3.js";
import "./chunk-6WDMQRZ6.js";
import "./chunk-A77LJ3EL.js";
import "./chunk-XE3QP43U.js";
import "./chunk-66JPAEYR.js";
import "./chunk-WDMUDEB6.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
