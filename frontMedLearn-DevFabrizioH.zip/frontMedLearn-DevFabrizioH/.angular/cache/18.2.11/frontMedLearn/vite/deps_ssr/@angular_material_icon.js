import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-5SHD7525.js";
import "./chunk-KLE2LZTR.js";
import "./chunk-RK2POULK.js";
import "./chunk-6QPZ7QDZ.js";
import "./chunk-I5TJEA3G.js";
import "./chunk-LXJI6YDO.js";
import "./chunk-EKRYF44B.js";
import "./chunk-NEMALUCI.js";
import "./chunk-2H3L6IVL.js";
import "./chunk-NQ4HTGF6.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
//# sourceMappingURL=@angular_material_icon.js.map
