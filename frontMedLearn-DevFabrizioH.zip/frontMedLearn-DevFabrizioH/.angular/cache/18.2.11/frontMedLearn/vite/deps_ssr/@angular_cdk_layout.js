import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BreakpointObserver,
  Breakpoints,
  LayoutModule,
  MediaMatcher
} from "./chunk-LXJI6YDO.js";
import "./chunk-EKRYF44B.js";
import "./chunk-NEMALUCI.js";
import "./chunk-2H3L6IVL.js";
import "./chunk-NQ4HTGF6.js";
export {
  BreakpointObserver,
  Breakpoints,
  LayoutModule,
  MediaMatcher
};
//# sourceMappingURL=@angular_cdk_layout.js.map
